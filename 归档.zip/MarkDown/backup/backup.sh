#!/bin/bash
# 配置备份目录
BACKUP_DIR=~/MarkDown
LOG_FILE=~/MarkDown/backup/git_backup.log
# 配置 Git 远程仓库分支
REMOTE_BRANCH="main"
# 超时时间（秒）
TIMEOUT=60

# 定义一个带超时的函数来执行 git push
function timeout_push() {
    perl -e '
        eval {
            local $SIG{ALRM} = sub { die "timeout\n" };
            alarm '$TIMEOUT';
            system(@ARGV);
            alarm 0;
        };
        if ($@) {
            exit(124) if $@ eq "timeout\n";
            die;
        }
    ' "$@"
}

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting backup..." >> "$LOG_FILE"

# 检查备份目录是否存在
if [ ! -d "$BACKUP_DIR" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Error: Backup directory not found: $BACKUP_DIR" >> "$LOG_FILE"
    exit 1
fi

cd "$BACKUP_DIR"

# 检查是否有 Git 仓库
if [ ! -d ".git" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Error: No Git repository found in $BACKUP_DIR" >> "$LOG_FILE"
    exit 1
fi

# 检测是否有文件更改（包括未追踪的文件）
if [ -z "$(git status --porcelain)" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] No changes detected. Backup skipped." >> "$LOG_FILE"
    exit 0
fi

# 添加所有更改到 Git 暂存区
git add . >> "$LOG_FILE" 2>&1

# 提交更改，附带时间戳
COMMIT_MESSAGE="Auto backup on $(date '+%Y-%m-%d %H:%M:%S')"
git commit -m "$COMMIT_MESSAGE" >> "$LOG_FILE" 2>&1

# 尝试直接推送到远程仓库
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Attempting direct push..." >> "$LOG_FILE"
timeout_push git push origin "$REMOTE_BRANCH" >> "$LOG_FILE" 2>&1
if [ $? -eq 0 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Direct push successful!" >> "$LOG_FILE"
else
    # 如果直接推送失败，切换到代理模式
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Direct push failed. Switching to proxy..." >> "$LOG_FILE"
    # 启用代理
    export https_proxy=http://127.0.0.1:7897 http_proxy=http://127.0.0.1:7897 all_proxy=socks5://127.0.0.1:7897
    
    # 重新尝试推送
    timeout_push git push origin "$REMOTE_BRANCH" >> "$LOG_FILE" 2>&1
    if [ $? -eq 0 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Proxy push successful!" >> "$LOG_FILE"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Proxy push failed. Backup unsuccessful." >> "$LOG_FILE"
        # 禁用代理
        unset http_proxy https_proxy all_proxy
        exit 1
    fi
    
    # 推送成功后禁用代理
    unset http_proxy https_proxy all_proxy
fi

# 记录成功日志
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Backup successful!" >> "$LOG_FILE"
exit 0