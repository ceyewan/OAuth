import os
import re


def add_space_between_zh_en(text):
    # 在中文和英文字符之间添加空格
    text = re.sub(r'([\u4e00-\u9fff])([\da-zA-Z])', r'\1 \2', text)
    text = re.sub(r'([\da-zA-Z])([\u4e00-\u9fff])', r'\1 \2', text)

    # 处理连续的空格，确保只有一个空格
    text = re.sub(r'\s+', ' ', text)
    return text


def process_markdown_file(file_path):
    try:
        # 读取文件内容
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 处理内容
        modified_content = add_space_between_zh_en(content)

        # 如果内容有变化，则写回文件
        if content != modified_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(modified_content)
            print(f"已优化文件: {file_path}")

    except Exception as e:
        print(f"处理文件 {file_path} 时出错: {str(e)}")


def process_directory(directory):
    # 遍历目录下的所有文件和子目录
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith('.md'):
                file_path = os.path.join(root, file)
                process_markdown_file(file_path)


if __name__ == "__main__":
    # 获取当前目录
    current_dir = os.getcwd()
    print(f"开始处理目录: {current_dir}")

    # 处理目录下的所有markdown文件
    process_directory(current_dir)

    print("处理完成!")
