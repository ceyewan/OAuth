## Containers：Linux Namespace and Cgroups

### Container

容器是一种轻量级的虚拟化技术，它允许你在操作系统上隔离运行的应用程序及其依赖环境。与传统的虚拟机（VM）不同，容器不包含完整的操作系统，而是共享宿主操作系统的内核。容器通过打包代码、运行时、系统工具和库，使得应用程序可以在不同的环境中一致运行。它的核心优势是高效、快速启动和资源占用少。

### Linux Namespace

Namespace 是 Linux 内核提供的一种资源隔离机制，用于将系统的全局资源分隔成独立的单元。每个命名空间内的进程只能看到属于自己命名空间的资源，而与其他命名空间隔离。常见的命名空间类型包括：

- **PID Namespace**：隔离进程 ID，容器内的进程有独立的 PID 编号。
- **Network Namespace**：隔离网络资源，如网络接口、IP 地址和端口。
- **Mount Namespace**：隔离文件系统挂载点，容器有自己的文件系统视图。
- **UTS Namespace**：隔离主机名和域名。
- **User Namespace**：隔离用户和组 ID，实现权限隔离。
- **IPC Namespace**：隔离进程间通信资源，如消息队列。

通过 Namespace，容器中的进程仿佛运行在一个独立的 " 操作系统 " 中，但实际上它们共享同一个内核。

创建一个 Linux 命名空间非常简单，我们使用一个名为 `unshare` 的包来创建一个独立的进程：

```go
sudo unshare --fork --pid --mount-proc bash
```

这条命令使用了 Linux 的 unshare 工具，它的作用是创建一个新的命名空间，并将后续的进程放入这个独立的命名空间中。让我们逐个分析选项：

- `unshare` 是一个 Linux 命令行工具，用于在当前进程中 " 脱离 " 某些全局命名空间，或者为新创建的进程分配独立的命名空间；
- `--fork` 这个选项告诉 unshare 在创建新的命名空间后，立即通过 fork() 系统调用创建一个子进程。新命名空间的隔离效果会应用到这个子进程，而不是当前的 shell。这样可以避免当前终端被隔离到一个新命名空间中；
- `--pid` 这个选项指定创建一个新的 **PID Namespace**（进程 ID 命名空间）。在新的 PID Namespace 中，子进程会拥有独立的进程 ID 空间，进程编号从 1 开始，且无法看到宿主系统或其他命名空间中的进程；
- `--mount-proc` 这个选项会在新的命名空间中重新挂载 /proc 文件系统。/proc 是一个虚拟文件系统，反映了当前进程的运行状态。如果不加这个选项，新 PID Namespace 中的 /proc /可能仍然显示宿主系统的进程列表；加上它后，/proc 只反映新命名空间内的进程。
- bash 这是 unshare 执行的命令，表示在新命名空间中启动一个新的 bash shell。所有后续命令都将在这个独立的 bash 中运行。

这条命令会创建一个独立的进程，并为其分配一个 `bash` shell。在该进程中运行 `ps` 命令时，你会发现只有两个进程：`bash` 和 `ps`。而在宿主系统中，你可以看到 `unshare` 进程，因为宿主系统能够查看所有全局进程，而新创建的命名空间是隔离的。

> - 这条命令没有使用 `--net` 选项，因此新进程仍然共享宿主系统的网络命名空间。如果加上（例如 `sudo unshare --fork --pid --net --mount-proc bash`），则会创建一个独立的 **Network Namespace**。
> - 在新的 Network Namespace 中，网络接口、IP 地址和路由表都与宿主隔离。你可以用 `ip link` 检查，发现默认只有一个 lo（回环接口），无法访问宿主的网络资源。这与 Docker 的网络隔离类似，Docker 会为每个容器分配独立的网络栈。

### Cgroups

Cgroup（Control Groups）是 Linux 内核的另一项功能，用于限制和管理进程组的资源使用。它可以控制 CPU、内存、磁盘 I/O、网络带宽等资源的分配和优先级。Cgroup 将进程组织成层次化的组，并为每个组设置资源限制或配额。例如：

- 限制一个容器只能使用 1GB 内存。
- 限制容器占用 CPU 的比例不超过 50%。

Cgroup 的核心作用是确保容器之间不会相互干扰，同时优化系统资源的分配。

Cgroups 将确定进程可以使用的 CPU 和内存限制。可以使用 cgcreate 和 cgexec 等工具手动创建并使用 Cgroup。

首先，需要安装 `cgroup-tools` 包，因为它提供了操作 Cgroup 的命令行工具。在基于 Debian 的系统（如 Ubuntu）上，可以运行 `sudo apt-get install cgroup-tools`。

使用 `cgcreate` 命令可以创建一个新的 Cgroup。例如：

```go
sudo cgcreate -g memory:my-process
```

- `cgcreate`：这是创建 Cgroup 的工具，负责在系统中定义一个新的控制组。
- `-g`：指定要控制的资源子系统（subsystem）和 Cgroup 的名称。这里 memory 表示我们要限制内存资源。
- `memory:my-process`：定义了资源类型和 Cgroup 的名称，memory 是子系统，my-process 是自定义的 Cgroup 名称。

执行这条命令后，系统会在 `/sys/fs/cgroup/memory` 目录下创建一个名为 `my-process` 的子目录。这个目录包含多个文件，用于设置和管理该 Cgroup 的资源限制。例如：

- `memory.limit_in_bytes`：设置该 Cgroup 中进程可使用的最大内存量，以字节为单位。
- `memory.kmem.limit_in_bytes`：限制内核内存使用。

要为 `my-process` Cgroup 设置一个 50MB 的内存限制，可以运行：

```go
sudo echo 50000000 >  /sys/fs/cgroup/memory/my-process/memory.limit_in_bytes
```

要启动一个受限于 my-process Cgroup 的进程，可以使用 cgexec 命令：

```go
sudo cgexec -g memory:my-process bash
```

- `cgexec`：这是一个工具，用于在指定 Cgroup 中执行命令或进程。
- `-g memory:my-process`：将进程分配到 memory:my-process 这个 Cgroup，其中 memory 是资源子系统，my-process 是 Cgroup 名称。
- `bash`：在新 Cgroup 中启动一个 bash shell。

### Cgroups with Namespace

Namespace 和 Cgroup 是实现容器的两大支柱，它们相辅相成：

1. **隔离（Namespace）**：Namespace 负责将容器的运行环境与宿主系统和其他容器隔离开来。例如，通过 PID Namespace，容器内的进程看不到宿主系统的其他进程；通过 Network Namespace，容器拥有独立的网络栈。
2. **资源控制（Cgroup）**：Cgroup 负责限制容器使用的资源，避免某个容器耗尽系统资源。例如，一个容器可能被限制在 2 个 CPU 核心和 512MB 内存内运行。
3. **协同作用**：Namespace 提供 " 边界 "，让容器内的进程感觉自己独占系统；Cgroup 提供 " 天花板 "，限制这个边界内的资源使用。二者结合，实现了既独立又可控的运行环境。

可以使用 cgroups 与 namespaces 来创建一个独立的进程，并限制其可使用的资源。

```go
sudo cgexec -g cpu,memory:my-process unshare -uinpUrf --mount-proc sh -c "/bin/hostname my-process && chroot mktemp -d /bin/sh"
```

1. **`cgexec -g cpu,memory:my-process`**
   - 使用 `cgexec` 在指定的 Cgroup 中运行后续命令。
   - **`-g cpu,memory:my-process`**：将进程放入名为 `my-process` 的 Cgroup，同时限制其 CPU 和内存资源。前提是你已通过 `cgcreate -g cpu,memory:my-process` 创建了这个 Cgroup，并设置了限制（如 `memory.limit_in_bytes`）。
2. **`unshare`**
   - 创建新的命名空间，实现进程环境的隔离。
   - **`-u`**（UTS Namespace）：隔离主机名和域名。
   - **`-i`**（IPC Namespace）：隔离进程间通信资源。
   - **`-n`**（Network Namespace）：隔离网络资源，如网络接口和 IP。
   - **`-p`**（PID Namespace）：隔离进程 ID，进程在新命名空间中从 PID 1 开始。
   - **`-U`**（User Namespace）：隔离用户和组 ID，支持权限隔离。
   - **`-r`**：将当前用户映射为新命名空间中的 root 用户（需配合 `-U`）。
   - **`-f`**（fork）：在新命名空间中 fork 一个子进程，避免影响当前 shell。
   - **`--mount-proc`**：在新 PID Namespace 中重新挂载 `/proc`，确保进程视图隔离。
3. **`sh -c "/bin/hostname my-process && chroot mktemp -d /bin/sh"`**
   - 在新环境中运行一个 shell，并执行指定的命令。
   - **`/bin/hostname my-process`**：设置新命名空间的主机名为 `my-process`（依赖 UTS Namespace）。
   - **`chroot mktemp -d /bin/sh`**：
     - **`mktemp -d`**：创建一个临时目录。
     - **`chroot`**：将进程的根文件系统切换到这个临时目录。
     - **`/bin/sh`**：在新根目录下启动一个 shell。

这条命令手动实现了一个简易容器：Namespace 提供隔离，Cgroup 提供资源控制，`chroot` 提供文件系统隔离。这正是 Docker 等容器技术的基础原理，只不过 Docker 封装得更高级（镜像管理、网络配置等）。

### Docker

Docker 是一个开源的容器化平台，基于 Namespace 和 Cgroup 等 Linux 内核技术，简化了容器的创建、管理和部署。Docker 在这些底层技术之上，提供了用户友好的工具和标准化的工作流程：

- **Docker Engine**：核心组件，负责创建和管理容器。
- **Docker Image**：容器的只读模板，包含应用程序及其依赖。
- **Docker Container**：从镜像启动的运行实例。
- **Dockerfile**：定义如何构建镜像的脚本。

Docker 的优势在于：

- **易用性**：通过简单的命令（如 docker run）即可启动容器。
- **标准化**：镜像可以在任何支持 Docker 的环境中运行。
- **生态系统**：Docker Hub 提供了丰富的预构建镜像。

简单来说，Docker 是对 Namespace 和 Cgroup 的高级封装，降低了容器技术的使用门槛，让开发者能更专注于应用开发而非底层实现。

## Deep into Container Runtime

容器的创建旨在提供一个独立的环境，让程序运行时不受同一主机上其他程序的干扰。然而，仅依赖 Linux 命名空间和 Cgroup 来运行容器会面临一些挑战。

第一个挑战是操作复杂。要创建一个容器，需要执行多条命令：创建命名空间、设置 Cgroup、配置资源限制；删除容器时，还需手动清理命名空间和 Cgroup。

第二个挑战是管理困难。当运行数十个容器时，如何追踪每个容器的状态、用途及关联进程？仅靠手动命令难以高效管理。

第三个挑战是重复劳动。许多容器已包含所需内容并存储在 Container Registry 上，但我们无法直接下载运行，只能从头构建，费时费力。

为何不开发一个工具，简化这些工作？只需一条命令即可创建或删除容器，同时管理多个运行中的容器，清晰显示每个容器的用途和进程。此外，该工具还能从网上下载现成容器。这就是容器运行时（Container Runtime）的由来。

Container Runtime 是管理容器生命周期的工具，涵盖创建、删除、打包和共享容器：

- **低级容器运行时**：专注于创建和删除容器。

- **高级容器运行时**：负责管理容器，下载镜像，解包后交给低级运行时以创建和运行容器。
  
    一些高级容器运行时甚至包括将容器打包成 Container Image 并将其传输到 Container Registry 的能力。

> - **Container Image** 是一个只读的、轻量级的文件包，包含了运行容器所需的所有内容：应用程序代码、运行时环境、系统库、配置文件等。它就像一个快照，捕捉了容器运行时的完整状态。在 Docker 中，你可以用 Dockerfile 定义镜像内容，然后通过 docker build 打包成镜像。
> - **Container Registry** 是一个存储和管理容器镜像的仓库，通常运行在云端或本地服务器上。它类似于代码的 GitHub，但专为容器镜像设计。

### 2.1 低级容器运行时

低级容器运行时是容器技术栈中的底层工具，主要负责创建和删除容器。它直接与 Linux 内核的特性（如 Cgroup 和 Namespace）交互，执行容器的核心操作，而不涉及高级管理功能（如镜像下载或容器编排）。它的任务是 " 启动一个隔离的、资源受限的进程 "，然后在任务完成后清理相关资源。低级容器运行时将执行以下操作：

- 使用 Cgroup（控制组）为容器分配资源限制，例如 CPU、内存等；
- 将命令行接口（CLI）或指定的程序放入 Cgroup，确保其运行受资源限制约束；
- 调用 unshare 或类似机制，创建多个命名空间（如 PID、Network、UTS 等），隔离容器的进程环境，使其与宿主和其他容器独立；
- 通过 chroot 或其他方式，为容器指定一个独立的根文件系统，通常从镜像中提取，确保容器有自己的文件环境。
- 在容器运行结束后，释放 Cgroup 和命名空间占用的资源，完成清理工作。

 `runc` 是最常见的低级容器运行时，由 Open Container Initiative（OCI）标准化，广泛应用于 Docker 等高级运行时底层。它的作用是根据配置文件（通常是 config.json）创建并运行容器。下面启动了一个名为 `runc-container` 的容器。

```go
runc run runc-container
```

### 2.2 高级容器运行时

高级容器运行时将专注于管理多个容器、传输和管理容器镜像，以及将容器镜像加载和解包到低级容器运行时。

 `containerd` 是一个常见的高级容器运行时，提供以下功能：

- 从 Container Registry 下载容器镜像。
- 管理镜像的存储与版本。
- 从镜像创建并运行容器。
- 管理容器的生命周期。

例如，我们将运行以下命令来创建一个 Redis 容器，该容器在容器注册表上有一个可用的 Redis 容器镜像。

- **下载镜像**：`sudo ctr images pull docker.io/library/redis:latest`
- **创建容器**：`sudo ctr container create docker.io/library/redis:latest redis`
- **删除容器**：`sudo ctr container delete redis`
- **列出内容**：`sudo ctr images list` 或 `sudo ctr container list`

尽管 containerd 支持从现有镜像运行容器，但它不提供镜像构建功能，也不注重用户界面（UI）支持。

为简化容器交互，**容器管理工具（Container Management）** 应运而生，Docker 便是其中之一，它在高级运行时基础上增加了构建镜像和友好的 UI 体验。

### 2.3 Docker

Docker 是最早全面支持容器交互的工具之一，提供以下功能：

- 构建镜像（`Dockerfile` / `docker build`）。
- 管理容器镜像（`docker images`）。
- 创建、删除和管理容器（`docker run`、`docker rm`、`docker ps`）。
- 共享容器镜像（`docker push`）。
- 提供用户界面（UI），替代纯命令行操作。

Docker 通过 API 与底层容器运行时交互，负责创建和管理容器。它依赖的高级运行时组件包括 `dockerd`、`docker-containerd` 和 `docker-runc`：

- **`dockerd`**：核心守护进程，提供镜像构建和管理功能。
- **`docker-containerd`**：类似于 `containerd`，负责容器生命周期管理。
- **`docker-runc`**：类似于 `runc`，执行低级容器创建。

## 3 K8s & Container Runtime

### 3.1 k8s 架构

![Pasted image 20250319165330](https://ceyewan.oss-cn-beijing.aliyuncs.com/typora/Pasted%20image%2020250319165330.png)

在 Kubernetes（K8s）集群中，主要包含 **主节点（Master Node）** 和 **工作节点（Worker Node）**。

- **主节点（Control Plane）** 负责管理整个集群，包括调度、监控和维护集群状态，同时向工作节点下发指令，例如运行指定的容器。
- **工作节点（Worker Node）** 主要负责运行实际的应用容器，并响应来自主节点的调度指令。

#### 3.1.1 主节点（Control Plane）核心组件

Control Plane 作为 Kubernetes 的控制中心，确保集群稳定运行，主要由以下核心组件构成：

- **etcd**：作为分布式键值存储，存储 Kubernetes 集群的所有配置信息和状态数据，包括 Pod、Service、配置文件等关键信息。保障数据一致性，所有控制组件均通过 API Server 访问 etcd 以获取或更新集群状态。
- **API server**：作为 Kubernetes 的核心通信入口，所有外部客户端（如 kubectl、Dashboard）和内部组件（如 Controller、Scheduler）均通过 API Server 进行交互。提供 RESTful API 接口，负责处理集群管理请求，并将变更同步到 etcd。
- **Controller Manager**：负责管理 Kubernetes 内部的各种控制器（Controller），以确保集群的实际状态符合用户设定的期望状态。
  - **ReplicaSet Controller**：确保 Pod 副本数量始终符合期望值（如自动扩缩容）。
  - **Node Controller**：监测节点状态，发现故障节点并触发相应恢复机制。
  - **Job Controller**：管理一次性任务（Job），确保任务按计划执行。
- **Scheduler**：负责根据集群资源（CPU、内存等）的使用情况，决定新创建的 Pod 应当运行在哪个工作节点上。

#### 3.1.2 工作节点（Worker Node）核心组件

Worker Node 主要用于运行实际的应用容器，核心组件包括：

- **kubelet**：负责与 Control Plane 通信，接收 API Server 下发的 Pod 运行指令，并管理本节点上的 Pod 和容器。监控容器运行状态，并向 Control Plane 反馈节点健康状况。
- **kube-proxy**：负责维护 Kubernetes 网络规则，确保集群内的 Pod 和 Service 之间的通信。实现负载均衡与网络转发，使 Service 能够将请求正确路由至后端 Pod。
- **Container Runtime（容器运行时）**：负责拉取容器镜像，并在工作节点上创建、运行和管理容器，典型的容器运行时包括 containerd、CRI-O 和 Docker。

### 3.2 k8s 如何管理集群中的容器

在 Kubernetes 集群中，**工作节点（Worker Node）** 负责运行应用容器，而 **kubelet** 是管理这些容器的核心组件。它运行在每个工作节点上，与主节点（Control Plane）通信，接收调度指令，并确保节点上的容器按照指定的配置正确运行。

kubelet 的主要职责包括监听来自主节点的容器调度事件，在工作节点上创建相应的容器，同时持续监控容器的运行状态，并定期向主节点上报节点健康状况。这保证了 Kubernetes 集群的稳定性和自动化管理能力。

为了与不同的容器运行时（如 containerd、CRI-O、Docker）交互，kubelet 通过 **容器运行时接口（Container Runtime Interface, CRI）** 作为中间层进行通信。CRS 充当适配层，使 kubelet 可以通过统一接口与各种容器运行时交互，而无需针对每种容器运行时进行额外适配。这种架构极大地提升了 Kubernetes 的灵活性和可扩展性，同时降低了 kubelet 的复杂性，使其能够专注于容器管理和集群协调任务。

![Pasted image 20250319164853](https://ceyewan.oss-cn-beijing.aliyuncs.com/typora/Pasted%20image%2020250319164853.png)

#### 3.2.1 Kubernetes 创建容器的完整流程

Kubernetes 创建容器的过程涉及多个核心组件，包括 **主节点（Control Plane）**、**kubelet** 以及 **容器运行时（Container Runtime）**，各组件协同工作以确保容器能够顺利创建并运行。

1. **主节点通知 kubelet 创建容器**
    当用户通过 kubectl apply 提交 Pod 资源时，**API Server** 接收该请求并将其存储到 **etcd**。随后，**Scheduler（调度器）** 评估集群资源情况，并选择合适的 **工作节点（Worker Node）** 来运行该 Pod。一旦调度完成，目标节点上的 **kubelet** 便会收到通知，要求它创建并运行容器。

2. **kubelet 通过 CRI 与高层容器运行时交互**
    kubelet 解析 Pod 规范，并与 **高层容器运行时（High-Level Container Runtime，如 containerd 或 CRI-O）** 进行交互。由于不同的 Kubernetes 部署可能使用不同的容器运行时，因此 Kubernetes 通过 **容器运行时接口（Container Runtime Interface, CRI）** 作为统一的通信层，使 kubelet 能够与不同的容器运行时兼容。kubelet 通过 CRI 发送创建容器的请求，触发后续容器镜像拉取及运行流程。

3. **高层容器运行时拉取容器镜像**
    高层容器运行时首先检查本地是否已缓存所需的容器镜像。如果镜像不存在，它会连接到 **容器镜像仓库（Container Image Registry，如 Docker Hub、Harbor、Google Container Registry）**，拉取所需的镜像文件。拉取完成后，它会解析镜像的各个层（Image Layers），解压缩并存储到磁盘上的 **镜像存储目录**（如 /var/lib/containerd），以供后续使用。

4. **低层容器运行时准备运行容器**
    高层容器运行时在完成镜像拉取后，会通知 **低层容器运行时（Low-Level Container Runtime，如 runc）**。低层容器运行时的职责是准备容器的运行环境，包括从磁盘加载镜像数据、创建容器的 **根文件系统（Root Filesystem）**，以及配置容器的 **Cgroups**（资源限制）、**Namespaces**（进程隔离）等内核机制，以确保容器能够在与宿主机隔离的环境中运行。

5. **低层容器运行时执行容器启动**
    一旦容器运行环境准备就绪，低层容器运行时会执行一系列命令，正式启动容器。首先，它会创建容器的 **PID 命名空间**，确保容器内部的进程与宿主机隔离。随后，它会初始化网络命名空间，使容器能够正确地与 Kubernetes 网络通信。最后，低层容器运行时会执行容器内的主进程（通常由 Dockerfile 中的 ENTRYPOINT 或 CMD 指定），此时容器正式进入运行状态，并开始处理来自外部的请求。

### 3.3 k8s 使用的 Container Runtime

最初，Kubernetes 主要使用 **Docker** 作为容器运行时。然而，从 **Kubernetes 1.24 版本开始，Docker 已被正式移除**，不再作为默认支持的运行时。这是因为 Kubernetes 需要通过 dockershim 组件来使 kubelet 兼容 Docker 的 API，而这一额外的适配层增加了系统的复杂性和维护成本。因此，官方决定移除 dockershim，并建议用户迁移到更符合 Kubernetes 生态的容器运行时，如 containerd 或 CRI-O。

相比于 Docker，**containerd** 作为一个更轻量级、专注于 Kubernetes 需求的容器运行时，成为了更推荐的选择。containerd 内置了 **CRI 插件**，使 kubelet 能够直接通过 **容器运行时接口（CRI）** 进行交互，而无需额外的适配层。这避免了 Docker 运行时中多层封装的复杂性，提高了运行效率和系统稳定性。因此，在现代 Kubernetes 集群中，containerd 已成为主流的容器运行时方案之一。

## 4 Build Your Own Container with Golang

```go
package main

import (
    "fmt"
    "os"
    "os/exec"
    "syscall"
)

func main() {
    switch os.Args[1] {
    case "run":
        parent()
    case "child":
        child()
    default:
        panic("wat should I do")
    }
}

func parent() {
    cmd := exec.Command("/proc/self/exe", append([]string{"child"}, os.Args[2:]...)...)
    cmd.SysProcAttr = &syscall.SysProcAttr{
        Cloneflags: syscall.CLONE_NEWUTS | syscall.CLONE_NEWPID | syscall.CLONE_NEWNS,
    }
    cmd.Stdin = os.Stdin
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr

    if err := cmd.Run(); err != nil {
        fmt.Println("ERROR", err)
        os.Exit(1)
    }
}

func child() {
    must(syscall.Mount("rootfs", "rootfs", "", syscall.MS_BIND, ""))
    must(os.MkdirAll("rootfs/oldrootfs", 0700))
    must(syscall.PivotRoot("rootfs", "rootfs/oldrootfs"))
    must(os.Chdir("/"))

    cmd := exec.Command(os.Args[2], os.Args[3:]...)
    cmd.Stdin = os.Stdin
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr

    if err := cmd.Run(); err != nil {
        fmt.Println("ERROR", err)
        os.Exit(1)
    }
}

func must(err error) {
    if err != nil {
        panic(err)
    }
}
```
