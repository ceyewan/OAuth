k8s 作为云原生时代的操作系统，学习它的必要性不言而喻! 本教程侧重于实战引导，以渐进式修改代码的方式，将从最基础的 container 容器的定义开始，经过 pod, deployment, service, ingress, configmap, secret 等资源直到用 helm 来打包部署一套完整服务。

## 1 准备工作

这我是看这篇 [参考教程](https://guangzhengli.com/courses/kubernetes) 做的笔记，内容全部来自于此。首先，我们需要安装 Docker，在 MacOS 上，可以使用 Orbstack 来安装，然后开启 k8s 模式，这样就不需要安装 minikube 来搭建环境了。

```mermaid
graph TD
    subgraph "客户端 (Client)"
        direction LR
        Mobile[Mobile App]
        WebApp[Web App]
        Desktop[Desktop App]
    end

    subgraph "基础设施 (Infrastructure)"
        direction TB
        APIGW[API 网关<br/>(如：Kong, Go-Gateway)]
        LB[负载均衡器<br/>(如：Nginx, HAProxy)]
        MQ[消息队列<br/>(如：Kafka, NATS, RabbitMQ)]
        Discovery[服务发现/注册<br/>(如：Consul, etcd)]
        Config[配置中心<br/>(如：Consul, etcd, Apollo)]
        DBs[数据库集群]
        Cache[分布式缓存<br/>(如：Redis)]
        Logging[日志聚合<br/>(如：ELK Stack)]
        Metrics[监控告警<br/>(如：Prometheus, Grafana)]
        Tracing[分布式追踪<br/>(如：Jaeger, Zipkin)]
        K8s[容器编排<br/>(Kubernetes)]
    end

    subgraph "核心微服务 (Go Microservices)"
        direction TB
        UserService[用户服务<br/>(注册, 登录, 用户资料)]
        AuthService[认证服务<br/>(Token 生成/校验)]
        ContactService[关系服务<br/>(好友, 群组管理)]
        PresenceService[在线状态服务<br/>(在线, 离线, 输入中)]
        MsgService[消息服务<br/>(消息收发, 存储, 离线消息)]
        GroupService[群组服务<br/>(群管理, 群消息)]
        GatewayService[连接层/网关服务<br/>(WebSocket/TCP 长连接管理)]
        PushService[推送服务<br/>(离线推送)]
        FileService[文件服务<br/>(图片, 语音, 文件传输)]
    end

    Mobile --> LB
    WebApp --> LB
    Desktop --> LB
    LB --> APIGW
    APIGW --> GatewayService
    APIGW --> UserService
    APIGW --> AuthService
    APIGW --> ContactService
    APIGW --> GroupService
    APIGW --> FileService

    GatewayService <--> MQ
    MsgService <--> MQ
    PushService <--> MQ
    PresenceService <--> MQ

    UserService -- gRPC/HTTP --> AuthService
    UserService -- CRUD --> DBs
    AuthService -- CRUD --> Cache
    AuthService -- CRUD --> DBs
    ContactService -- CRUD --> DBs
    PresenceService -- CRUD --> Cache
    PresenceService -- CRUD --> DBs
    MsgService -- CRUD --> DBs
    GroupService -- CRUD --> DBs
    FileService -- CRUD --> DBs & Object Storage

    UserService <--> Discovery
    AuthService <--> Discovery
    ContactService <--> Discovery
    PresenceService <--> Discovery
    MsgService <--> Discovery
    GroupService <--> Discovery
    GatewayService <--> Discovery
    PushService <--> Discovery
    FileService <--> Discovery

    UserService --> Config
    AuthService --> Config
    ContactService --> Config
    PresenceService --> Config
    MsgService --> Config
    GroupService --> Config
    GatewayService --> Config
    PushService --> Config
    FileService --> Config

    UserService --> Logging & Metrics & Tracing
    AuthService --> Logging & Metrics & Tracing
    ContactService --> Logging & Metrics & Tracing
    PresenceService --> Logging & Metrics & Tracing
    MsgService --> Logging & Metrics & Tracing
    GroupService --> Logging & Metrics & Tracing
    GatewayService --> Logging & Metrics & Tracing
    PushService --> Logging & Metrics & Tracing
    FileService --> Logging & Metrics & Tracing

    K8s -- Manages --> UserService
    K8s -- Manages --> AuthService
    K8s -- Manages --> ContactService
    K8s -- Manages --> PresenceService
    K8s -- Manages --> MsgService
    K8s -- Manages --> GroupService
    K8s -- Manages --> GatewayService
    K8s -- Manages --> PushService
    K8s -- Manages --> FileService
```
